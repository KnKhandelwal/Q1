import React, { useState } from 'react'; import axios from 'axios';

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080';

export default function FileUpload({ onOk }:{ onOk?:()=>void }){
  const [file, setFile] = useState<File | null>(null);
  const [msg, setMsg] = useState('');

  const upload = async ()=>{
    if(!file){ setMsg('Select a file'); return }
    const allowed = ['image/png','image/jpeg','image/jpg','application/pdf','text/plain'];
    if(!allowed.includes(file.type)){ setMsg('Unsupported file type'); return }
    if(file.size > 5*1024*1024){ setMsg('File too large (max 5MB)'); return }
    const fd = new FormData(); fd.append('file', file);
    try{
      const res = await axios.post(API + '/api/files/upload', fd, { headers:{ 'Content-Type': 'multipart/form-data' } });
      setMsg('Uploaded: ' + res.data.filename);
      setFile(null);
      onOk?.();
    }catch(e:any){
      setMsg(e?.response?.data?.error || 'Upload failed');
    }
  }

  return (<div className="space-y-3">
    <div className="flex items-center gap-3">
      <input type="file" onChange={e=>setFile(e.target.files ? e.target.files[0] : null)} />
      <button className="px-4 py-2 bg-indigo-600 text-white rounded" onClick={upload}>Upload</button>
    </div>
    {msg && <div className="text-sm text-gray-600">{msg}</div>}
  </div>)
}