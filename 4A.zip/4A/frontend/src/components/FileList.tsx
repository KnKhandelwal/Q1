import React from 'react';
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080';
export default function FileList({ files, onRefresh }:{ files:string[]; onRefresh?:()=>void }){
  return (<div className="space-y-3">
    <div className="flex items-center justify-between mb-2">
      <div className="text-lg font-semibold">Files</div>
      <button className="px-3 py-1 border rounded" onClick={onRefresh}>Refresh</button>
    </div>
    {files.length===0 && <div className="text-gray-500">No files uploaded yet.</div>}
    <ul className="space-y-2">
      {files.map(f=> <li key={f} className="flex items-center justify-between">
        <div className="text-sm">{f}</div>
        <div className="flex gap-2">
          <a href={API + '/api/files/' + encodeURIComponent(f)} target="_blank" rel="noreferrer" className="px-3 py-1 bg-slate-100 rounded">Download</a>
        </div>
      </li>)}
    </ul>
  </div>)
}