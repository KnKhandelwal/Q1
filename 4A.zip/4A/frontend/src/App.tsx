import React, { useEffect, useState } from 'react'; import axios from 'axios'; import FileUpload from './components/FileUpload'; import FileList from './components/FileList';

const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080';

export default function App(){ 
  const [files, setFiles] = useState<string[]>([]);
  const load = ()=> axios.get(API + '/api/files').then(r=>setFiles(r.data)).catch(()=>setFiles([]));
  useEffect(()=>{ load() },[]);
  return (<div className="min-h-screen bg-slate-50 p-6">
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">4A — File Upload & Download</h1>
      <div className="card mb-4"><FileUpload onOk={()=>load()} /></div>
      <div className="card"><FileList files={files} onRefresh={load} /></div>
    </div>
  </div>)
}