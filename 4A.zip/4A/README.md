# 4A — File Upload & Download (Spring Boot + React)
Features:
- Upload files via multipart POST /api/files/upload
- List files: GET /api/files
- Download file: GET /api/files/{filename}
- Basic validation: max 5MB, allowed types: images, pdf, text
- Frontend includes upload form and download links

Run backend:
cd backend
mvn spring-boot:run

Run frontend:
cd frontend
npm install
npm run dev
