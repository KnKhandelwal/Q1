package com.example.fileapp.service;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class FileStorageService {

    private final Path root = Paths.get("uploads");

    @PostConstruct
    public void init() throws IOException {
        if (!Files.exists(root)) Files.createDirectories(root);
    }

    public String store(MultipartFile file) throws IOException {
        String filename = Path.of(file.getOriginalFilename()).getFileName().toString();
        if (filename.contains("..")) throw new IOException("Invalid filename");
        Path dest = root.resolve(filename);
        Files.copy(file.getInputStream(), dest, StandardCopyOption.REPLACE_EXISTING);
        return filename;
    }

    public Resource loadAsResource(String filename) throws MalformedURLException {
        Path file = root.resolve(filename);
        Resource resource = new UrlResource(file.toUri());
        if (resource.exists() || resource.isReadable()) return resource;
        throw new RuntimeException("Could not read file: " + filename);
    }

    public List<String> listFiles() throws IOException {
        try (Stream<Path> stream = Files.list(root)) {
            return stream.filter(p -> !Files.isDirectory(p)).map(p -> p.getFileName().toString()).collect(Collectors.toList());
        }
    }

    public void deleteAll() throws IOException {
        FileSystemUtils.deleteRecursively(root);
        Files.createDirectories(root);
    }
}
