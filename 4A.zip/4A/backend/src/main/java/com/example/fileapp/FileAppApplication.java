package com.example.fileapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(FileAppApplication.class, args);
    }
}
