
INSERT INTO PRODUCT (id, name, brand, category, thumbnail, description, price, mrp, stock) VALUES
  (1, 'Noise Cancelling Headphones', 'SonicCo', 'Audio', 'https://images.unsplash.com/photo-1518449363931-4f033a6fac2c', 'Immersive over-ear ANC headphones with 30h battery life.', 5999, 7999, 25),
  (2, 'Mechanical Keyboard', 'KeyPro', 'Peripherals', 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8', 'Hot-swappable blue switches, RGB, aluminum frame.', 4499, 5999, 40),
  (3, '4K Monitor 27"', 'ViewEdge', 'Displays', 'https://images.unsplash.com/photo-1517336714731-489689fd1ca9', 'Crisp 4K IPS panel, 99% sRGB, 60Hz.', 23999, 26999, 12),
  (4, 'Wireless Mouse', 'SwiftTech', 'Peripherals', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9', 'Ergonomic design with adaptive DPI.', 1299, 1599, 100),
  (5, 'USB-C Hub 8-in-1', 'Portify', 'Accessories', 'https://images.unsplash.com/photo-1555617117-08eb8e6a1df2', 'HDMI, 3xUSB-A, SD/TF, Ethernet, PD.', 1999, 2499, 65),
  (6, 'Portable SSD 1TB', 'DataDash', 'Storage', 'https://images.unsplash.com/photo-1518779578993-ec3579fee39f', 'NVMe-based, up to 1050MB/s.', 7499, 9999, 30);
