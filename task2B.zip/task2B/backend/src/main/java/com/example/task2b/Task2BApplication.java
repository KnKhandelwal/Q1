package com.example.task2b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task2BApplication {
    public static void main(String[] args) {
        SpringApplication.run(Task2BApplication.class, args);
    }
}
