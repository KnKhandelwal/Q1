package com.example.task2b.repo;

import com.example.task2b.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("SELECT p FROM Product p WHERE " +
            "LOWER(p.name) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
            "LOWER(p.brand) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
            "LOWER(p.category) LIKE LOWER(CONCAT('%', :q, '%'))")
    List<Product> search(String q);
}
