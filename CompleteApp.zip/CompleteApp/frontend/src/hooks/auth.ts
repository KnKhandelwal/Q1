import axios from 'axios'
const API = import.meta.env.VITE_API_BASE || 'http://localhost:8080'
export function api(){ const inst = axios.create({ baseURL: API }); inst.interceptors.request.use(cfg=>{ const t = localStorage.getItem('completeapp.token'); if(t) cfg.headers['Authorization']='Bearer '+t; return cfg; }); return inst; }
export function saveToken(token:string){ localStorage.setItem('completeapp.token', token); }
export function token(){ return localStorage.getItem('completeapp.token'); }
export function logout(){ localStorage.removeItem('completeapp.token'); }
