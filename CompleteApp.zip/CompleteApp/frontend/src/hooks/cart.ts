import { useEffect, useMemo, useState } from 'react'
export default function useCart(){
  const [items, setItems] = useState<any[]>(()=>{ const raw=localStorage.getItem('completeapp.cart'); return raw? JSON.parse(raw): []; })
  useEffect(()=>{ localStorage.setItem('completeapp.cart', JSON.stringify(items)); },[items])
  const add = (p:any, qty=1)=> setItems(prev=>{ const f=prev.find(i=>i.product.id===p.id); if(f) return prev.map(i=>i.product.id===p.id? {...i, qty:i.qty+qty}: i); return [...prev, {product:p, qty}]; })
  const remove = (id:number)=> setItems(prev=>prev.filter(i=>i.product.id!==id))
  const clear = ()=> setItems([])
  const total = useMemo(()=> items.reduce((s,i)=>s+i.product.price*i.qty,0),[items])
  const count = useMemo(()=> items.reduce((s,i)=>s+i.qty,0),[items])
  return {items, add, remove, clear, total, count}
}
