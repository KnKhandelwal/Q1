import React from 'react'
import Navbar from '../components/Navbar'
export default function Home(){ return (<div className='container'><Navbar/><div className='card'><h1 className='text-2xl font-bold'>Welcome to CompleteApp</h1><p className='text-gray-600'>A demo combining profiles, products, auth, files and real-time chat.</p></div></div>) }
