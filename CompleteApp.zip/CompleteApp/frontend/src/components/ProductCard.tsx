import { Link } from 'react-router-dom'
export default function ProductCard({p, onAdd}:{p:any, onAdd:(p:any)=>void}){
  return (<div className="card"><img src={p.thumbnail} className="w-full h-40 object-cover rounded-md mb-3"/><div className="font-semibold">{p.name}</div><div className="text-sm text-gray-500">{p.brand}</div><div className="mt-2 flex items-center justify-between"><div className="font-bold">₹{p.price}</div><div><button className="btn btn-primary" onClick={()=>onAdd(p)}>Add</button><Link to={'/product/'+p.id} className="ml-2">Details</Link></div></div></div>) }
