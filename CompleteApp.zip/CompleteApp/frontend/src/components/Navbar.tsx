import { Link } from 'react-router-dom'
import { logout, token } from '../hooks/auth'
export default function Navbar({count=0}:{count?:number}){
  const logged = !!token()
  return (<header className="card mb-4"><div className="container flex items-center gap-4"><Link to="/" className="font-bold text-lg">CompleteApp</Link><nav className="ml-auto flex gap-2"><Link to="/products" className="text-sm">Products</Link><Link to="/profiles" className="text-sm">Profiles</Link><Link to="/upload" className="text-sm">Files</Link><Link to="/chat" className="text-sm">Chat</Link><Link to="/products" className="btn btn-primary">Cart ({count})</Link>{logged? <button className="btn" onClick={()=>{logout();window.location.href='/';}}>Logout</button> : <Link to='/login' className='btn'>Login</Link>}</nav></div></header>) }
