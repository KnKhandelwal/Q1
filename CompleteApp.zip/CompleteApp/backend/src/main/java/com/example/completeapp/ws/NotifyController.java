package com.example.completeapp.ws;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import java.time.Instant;
import java.util.Map;

@Controller
public class NotifyController {
    @MessageMapping("/notify")
    @SendTo("/topic/notifications")
    public Map<String,Object> notify(Map<String,Object> payload){
        payload.put("serverTime", Instant.now().toEpochMilli());
        return payload;
    }
}
