package com.example.completeapp.config;

import com.example.completeapp.model.AppUser;
import com.example.completeapp.model.Product;
import com.example.completeapp.repo.ProductRepository;
import com.example.completeapp.repo.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@Configuration
public class DataLoader {
    @Bean CommandLineRunner init(UserRepository users, ProductRepository products, PasswordEncoder encoder){
        return args -> {
            if (!users.existsByUsername("admin")) users.save(new AppUser("admin", encoder.encode("admin123"), "ROLE_ADMIN,ROLE_USER"));
            if (!users.existsByUsername("user")) users.save(new AppUser("user", encoder.encode("user123"), "ROLE_USER"));
            if (products.count()==0){
                products.save(new Product("Noise Cancelling Headphones","SonicCo","Audio","Immersive ANC headphones", new BigDecimal(5999),25,"https://images.unsplash.com/photo-1518449363931-4f033a6fac2c"));
                products.save(new Product("Mechanical Keyboard","KeyPro","Peripherals","Hot-swappable, RGB", new BigDecimal(4499),40,"https://images.unsplash.com/photo-1517336714731-489689fd1ca8"));
                products.save(new Product("4K Monitor 27\"","ViewEdge","Displays","Crisp 4K IPS panel", new BigDecimal(23999),12,"https://images.unsplash.com/photo-1518779578993-ec3579fee39f"));
            }
        };
    }
}
