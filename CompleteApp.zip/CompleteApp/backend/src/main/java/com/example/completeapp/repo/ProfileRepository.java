package com.example.completeapp.repo;
import com.example.completeapp.model.Profile;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProfileRepository extends JpaRepository<Profile, Long> {}
