package com.example.completeapp.controller;

import com.example.completeapp.model.Product;
import com.example.completeapp.repo.ProductRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = {"http://localhost:5173","http://localhost:3000"})
public class ProductController {
    private final ProductRepository repo;
    public ProductController(ProductRepository repo){ this.repo=repo; }
    @GetMapping public List<Product> all(){ return repo.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Product> byId(@PathVariable Long id){ return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping("/admin") public ResponseEntity<Product> create(@RequestBody Product p){ return ResponseEntity.ok(repo.save(p)); }
}
