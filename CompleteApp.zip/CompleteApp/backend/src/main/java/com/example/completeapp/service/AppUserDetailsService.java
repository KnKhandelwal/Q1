package com.example.completeapp.service;

import com.example.completeapp.model.AppUser;
import com.example.completeapp.repo.UserRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.Arrays;

@Service
public class AppUserDetailsService implements UserDetailsService {
    private final UserRepository repo;
    public AppUserDetailsService(UserRepository repo){ this.repo=repo; }
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser u = repo.findByUsername(username).orElseThrow(()-> new UsernameNotFoundException("User not found"));
        Set<GrantedAuthority> auth = Arrays.stream(u.getRoles().split(",")).map(String::trim).map(SimpleGrantedAuthority::new).collect(Collectors.toSet());
        return new User(u.getUsername(), u.getPassword(), auth);
    }
}
