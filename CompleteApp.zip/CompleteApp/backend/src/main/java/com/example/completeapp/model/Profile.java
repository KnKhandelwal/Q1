package com.example.completeapp.model;

import jakarta.persistence.*;

@Entity
public class Profile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;
    private String email;
    private String phone;
    private String bio;
    private String avatar; // filename for uploaded avatar

    public Profile() {}
    public Profile(String fullName, String email, String phone, String bio, String avatar){
        this.fullName=fullName; this.email=email; this.phone=phone; this.bio=bio; this.avatar=avatar;
    }
    public Long getId(){return id;} public String getFullName(){return fullName;} public void setFullName(String f){this.fullName=f;}
    public String getEmail(){return email;} public void setEmail(String e){this.email=e;}
    public String getPhone(){return phone;} public void setPhone(String p){this.phone=p;}
    public String getBio(){return bio;} public void setBio(String b){this.bio=b;}
    public String getAvatar(){return avatar;} public void setAvatar(String a){this.avatar=a;}
}
