package com.example.completeapp.controller;

import com.example.completeapp.model.AppUser;
import com.example.completeapp.repo.UserRepository;
import com.example.completeapp.security.JwtService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = {"http://localhost:5173","http://localhost:3000"})
public class AuthController {
    record RegisterReq(@NotBlank @Size(min=3,max=30) String username, @NotBlank @Size(min=6) String password) {}
    record LoginReq(@NotBlank String username, @NotBlank String password) {}
    record AuthResp(String token, String username, String roles) {}

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    public AuthController(UserRepository users, PasswordEncoder encoder, AuthenticationManager authManager, JwtService jwtService){ this.users=users; this.encoder=encoder; this.authManager=authManager; this.jwtService=jwtService; }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterReq r){
        if (users.existsByUsername(r.username())) return ResponseEntity.badRequest().body(Map.of("error","Username exists"));
        AppUser u = new AppUser(r.username(), encoder.encode(r.password()), "ROLE_USER");
        users.save(u);
        Map<String,Object> extra=new HashMap<>(); extra.put("roles", u.getRoles());
        String token = jwtService.generateToken(u.getUsername(), extra);
        return ResponseEntity.ok(new AuthResp(token,u.getUsername(),u.getRoles()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginReq r){
        authManager.authenticate(new UsernamePasswordAuthenticationToken(r.username(), r.password()));
        AppUser u = users.findByUsername(r.username()).orElseThrow();
        Map<String,Object> extra=new HashMap<>(); extra.put("roles", u.getRoles());
        String token = jwtService.generateToken(u.getUsername(), extra);
        return ResponseEntity.ok(new AuthResp(token,u.getUsername(),u.getRoles()));
    }
}
