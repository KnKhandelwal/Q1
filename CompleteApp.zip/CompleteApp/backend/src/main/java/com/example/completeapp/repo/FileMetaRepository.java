package com.example.completeapp.repo;
import com.example.completeapp.model.FileMeta;
import org.springframework.data.jpa.repository.JpaRepository;
public interface FileMetaRepository extends JpaRepository<FileMeta, Long> {
    FileMeta findByFilename(String filename);
}
