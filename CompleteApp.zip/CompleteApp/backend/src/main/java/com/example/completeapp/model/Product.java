package com.example.completeapp.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String name; private String brand; private String category;
    @Column(length=1000) private String description; private BigDecimal price; private Integer stock;
    private String thumbnail;
    public Product() {}
    public Product(String name,String brand,String category,String description,BigDecimal price,Integer stock,String thumbnail){
        this.name=name;this.brand=brand;this.category=category;this.description=description;this.price=price;this.stock=stock;this.thumbnail=thumbnail;
    }
    public Long getId(){return id;} public String getName(){return name;} public void setName(String n){this.name=n;}
    public String getBrand(){return brand;} public void setBrand(String b){this.brand=b;}
    public String getCategory(){return category;} public void setCategory(String c){this.category=c;}
    public String getDescription(){return description;} public void setDescription(String d){this.description=d;}
    public java.math.BigDecimal getPrice(){return price;} public void setPrice(java.math.BigDecimal p){this.price=p;}
    public Integer getStock(){return stock;} public void setStock(Integer s){this.stock=s;}
    public String getThumbnail(){return thumbnail;} public void setThumbnail(String t){this.thumbnail=t;}
}
