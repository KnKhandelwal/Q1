package com.example.completeapp.model;

import jakarta.persistence.*;

@Entity
public class FileMeta {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String filename;
    private String contentType;
    private Long size;
    public FileMeta() {}
    public FileMeta(String filename,String contentType,Long size){this.filename=filename;this.contentType=contentType;this.size=size;}
    public Long getId(){return id;} public String getFilename(){return filename;} public void setFilename(String f){this.filename=f;}
    public String getContentType(){return contentType;} public void setContentType(String c){this.contentType=c;}
    public Long getSize(){return size;} public void setSize(Long s){this.size=s;}
}
