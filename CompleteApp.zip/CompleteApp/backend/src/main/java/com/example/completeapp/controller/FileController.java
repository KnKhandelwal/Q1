package com.example.completeapp.controller;

import com.example.completeapp.model.FileMeta;
import com.example.completeapp.service.FileStorageService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/files")
@CrossOrigin(origins = {"http://localhost:5173","http://localhost:3000"})
public class FileController {
    private final FileStorageService storage;
    public FileController(FileStorageService storage){ this.storage = storage; }

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestPart("file") MultipartFile file){
        try {
            if (file.getSize() > 8*1024*1024) return ResponseEntity.badRequest().body(Map.of("error","File too large (max 8MB)"));
            String ct = file.getContentType()==null? "": file.getContentType();
            if (!ct.startsWith("image/") && !ct.equals("application/pdf") && !ct.startsWith("text/")) return ResponseEntity.badRequest().body(Map.of("error","Unsupported file type"));
            var meta = storage.store(file);
            return ResponseEntity.ok(Map.of("filename", meta.getFilename(), "id", meta.getId()));
        } catch (IOException e) { return ResponseEntity.internalServerError().body(Map.of("error","Failed to store file")); }
    }

    @GetMapping public ResponseEntity<List<FileMeta>> list() throws IOException { return ResponseEntity.ok(storage.list()); }

    @GetMapping("/{filename:.+}")
    public ResponseEntity<Resource> download(@PathVariable String filename, HttpServletRequest request){
        try {
            Resource res = storage.loadAsResource(filename);
            String contentType = request.getServletContext().getMimeType(res.getFile().getAbsolutePath());
            if (contentType==null) contentType = "application/octet-stream";
            return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType)).header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="" + res.getFilename() + """).body(res);
        } catch (MalformedURLException e) { return ResponseEntity.notFound().build(); } catch (IOException e){ return ResponseEntity.internalServerError().build(); }
    }
}
