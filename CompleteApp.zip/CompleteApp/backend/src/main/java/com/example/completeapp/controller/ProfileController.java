package com.example.completeapp.controller;

import com.example.completeapp.model.Profile;
import com.example.completeapp.repo.ProfileRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/profiles")
@CrossOrigin(origins = {"http://localhost:5173","http://localhost:3000"})
public class ProfileController {
    private final ProfileRepository repo;
    public ProfileController(ProfileRepository repo){ this.repo=repo; }
    @GetMapping public List<Profile> all(){ return repo.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Profile> byId(@PathVariable Long id){ return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public Profile create(@RequestBody Profile p){ return repo.save(p); }
    @PutMapping("/{id}") public ResponseEntity<Profile> update(@PathVariable Long id, @RequestBody Profile p){ return repo.findById(id).map(old->{ old.setFullName(p.getFullName()); old.setEmail(p.getEmail()); old.setPhone(p.getPhone()); old.setBio(p.getBio()); old.setAvatar(p.getAvatar()); return ResponseEntity.ok(repo.save(old)); }).orElse(ResponseEntity.notFound().build()); }
    @DeleteMapping("/{id}") public ResponseEntity<?> delete(@PathVariable Long id){ repo.deleteById(id); return ResponseEntity.ok().build(); }
}
