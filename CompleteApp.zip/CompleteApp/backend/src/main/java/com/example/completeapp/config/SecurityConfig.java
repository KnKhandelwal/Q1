package com.example.completeapp.config;

import com.example.completeapp.security.JwtAuthFilter;
import com.example.completeapp.service.AppUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SecurityConfig {
    private final AppUserDetailsService uds;
    private final com.example.completeapp.security.JwtService jwtService;
    public SecurityConfig(AppUserDetailsService uds, com.example.completeapp.security.JwtService jwtService){ this.uds=uds; this.jwtService=jwtService; }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        JwtAuthFilter f = new JwtAuthFilter(jwtService, uds);
        http.csrf(csrf->csrf.disable())
            .cors(c->{})
            .headers(h->h.frameOptions(f->f.disable()))
            .sessionManagement(sm->sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**","/api/products","/api/files/**","/ws/**","/app/**","/topic/**","/swagger-ui.html","/v3/api-docs/**","/h2-console/**").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .requestMatchers("/api/user/**","/api/profiles/**").hasAnyRole("USER","ADMIN")
                .anyRequest().permitAll()
            )
            .authenticationProvider(authenticationProvider())
            .addFilterBefore(f, org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    @Bean public DaoAuthenticationProvider authenticationProvider(){ DaoAuthenticationProvider p = new DaoAuthenticationProvider(); p.setUserDetailsService(uds); p.setPasswordEncoder(passwordEncoder()); return p; }
    @Bean public PasswordEncoder passwordEncoder(){ return new BCryptPasswordEncoder(); }
    @Bean public AuthenticationManager authenticationManager(AuthenticationConfiguration c) throws Exception { return c.getAuthenticationManager(); }
    @Bean public WebMvcConfigurer corsConfigurer(){ return new WebMvcConfigurer(){ @Override public void addCorsMappings(CorsRegistry registry){ registry.addMapping("/**").allowedOrigins("http://localhost:5173","http://localhost:3000").allowedMethods("GET","POST","PUT","DELETE","OPTIONS"); } }; }
}
