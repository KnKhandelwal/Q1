package com.example.completeapp.security;

import com.example.completeapp.service.AppUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

public class JwtAuthFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final AppUserDetailsService uds;
    public JwtAuthFilter(JwtService jwtService, AppUserDetailsService uds){ this.jwtService=jwtService; this.uds=uds; }
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        final String authHeader = request.getHeader("Authorization");
        if (authHeader==null || !authHeader.startsWith("Bearer ")) { filterChain.doFilter(request,response); return; }
        final String token = authHeader.substring(7);
        String username;
        try { username = jwtService.extractUsername(token); } catch(Exception e){ filterChain.doFilter(request,response); return; }
        if (username!=null && SecurityContextHolder.getContext().getAuthentication()==null){
            UserDetails ud = uds.loadUserByUsername(username);
            if (jwtService.isTokenValid(token, ud.getUsername())){
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(ud, null, ud.getAuthorities());
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }
        filterChain.doFilter(request,response);
    }
}
