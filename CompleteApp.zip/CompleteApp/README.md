# CompleteApp — Combined Full-Stack Application
Features:
1. User profiles CRUD (Spring Boot + React)
2. Product catalog + cart (frontend state)
3. JWT Authentication (register/login) and protected endpoints
4. File upload & download (local storage, validation)
5. Real-time notifications/chat (WebSocket STOMP + SockJS)

Run backend:
cd backend
mvn spring-boot:run

Run frontend:
cd frontend
npm install
npm run dev

Default credentials:
- admin / admin123 (ROLE_ADMIN,ROLE_USER)
- user / user123 (ROLE_USER)
