import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8080'

export function api() {
  const instance = axios.create({ baseURL: API_BASE })
  instance.interceptors.request.use(config => {
    const token = localStorage.getItem('3a.token')
    if (token) config.headers['Authorization'] = `Bearer ${token}`
    return config
  })
  return instance
}

export function saveToken(token: string) {
  localStorage.setItem('3a.token', token)
}
export function logout() {
  localStorage.removeItem('3a.token')
}
export function token() { return localStorage.getItem('3a.token') }
