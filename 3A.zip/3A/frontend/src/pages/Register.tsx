import { FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import { api, saveToken } from '../hooks/auth'

export default function Register() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      const res = await api().post('/api/auth/register', { username, password })
      saveToken(res.data.token)
      navigate('/')
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Registration failed')
    }
  }

  return (
    <div>
      <Navbar />
      <main className="container-lg py-10 max-w-md">
        <h1 className="text-2xl font-bold mb-4">Register</h1>
        <form onSubmit={onSubmit} className="card space-y-3">
          {error && <div className="text-red-600">{error}</div>}
          <input className="input" placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
          <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          <button className="btn btn-primary w-full" type="submit">Create account</button>
          <div className="text-sm text-gray-600">Already have an account? <Link to="/login" className="text-indigo-600">Login</Link></div>
        </form>
      </main>
    </div>
  )
}
