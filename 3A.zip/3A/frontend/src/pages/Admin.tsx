import { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { api, token } from '../hooks/auth'
import { useNavigate } from 'react-router-dom'

export default function Admin() {
  const navigate = useNavigate()
  const [message, setMessage] = useState<string>('Loading...')

  useEffect(() => {
    if (!token()) {
      setMessage('Not authenticated')
      navigate('/login')
      return
    }
    api().get('/api/admin/hello')
      .then(res => setMessage(res.data.message))
      .catch(() => setMessage('Access denied (need ADMIN role)'))
  }, [])

  return (
    <div>
      <Navbar />
      <main className="container-lg py-10">
        <h1 className="text-2xl font-bold mb-3">Admin Area (protected)</h1>
        <div className="card">{message}</div>
      </main>
    </div>
  )
}
