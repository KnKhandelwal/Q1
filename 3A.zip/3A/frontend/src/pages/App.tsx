import { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import { Product } from '../types'
import { api } from '../hooks/auth'

export default function App() {
  const [products, setProducts] = useState<Product[]>([])
  useEffect(() => {
    api().get('/api/products').then(res => setProducts(res.data))
  }, [])

  return (
    <div>
      <Navbar />
      <main className="container-lg py-6">
        <h1 className="text-2xl font-bold mb-4">Products</h1>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map(p => (
            <div key={p.id} className="card">
              <div className="aspect-video bg-gray-100 rounded-xl overflow-hidden mb-3">
                <img src={p.thumbnail} alt={p.name} className="w-full h-full object-cover"/>
              </div>
              <div className="font-semibold">{p.name}</div>
              <div className="text-sm text-gray-500">{p.brand} • {p.category}</div>
              <div className="mt-2 text-lg font-semibold">₹{p.price}</div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
