import { Link, useNavigate } from 'react-router-dom'
import { logout, token } from '../hooks/auth'

export default function Navbar() {
  const navigate = useNavigate()
  const loggedIn = !!token()
  return (
    <header className="border-b bg-white">
      <div className="container-lg py-4 flex items-center gap-3">
        <Link to="/" className="text-2xl font-bold text-indigo-700">3A</Link>
        <nav className="ml-auto flex items-center gap-3">
          <Link to="/" className="btn btn-outline">Home</Link>
          <Link to="/admin" className="btn btn-outline">Admin</Link>
          {!loggedIn ? (
            <>
              <Link to="/login" className="btn btn-primary">Login</Link>
              <Link to="/register" className="btn btn-outline">Register</Link>
            </>
          ) : (
            <button className="btn btn-outline" onClick={() => { logout(); navigate('/'); }}>Logout</button>
          )}
        </nav>
      </div>
    </header>
  )
}
