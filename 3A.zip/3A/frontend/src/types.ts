export type AuthUser = { username: string; roles: string }
export type Product = {
  id: number; name: string; brand: string; category: string;
  thumbnail: string; description: string; price: number; mrp: number; stock: number;
}
