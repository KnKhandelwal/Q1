package com.example.threea.controller;

import com.example.threea.model.Product;
import com.example.threea.repo.ProductRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = {"http://localhost:5173","http://localhost:3000"})
public class ProductController {

    private final ProductRepository repo;

    public ProductController(ProductRepository repo) {
        this.repo = repo;
    }

    // Public listing (no auth)
    @GetMapping
    public List<Product> all() {
        return repo.findAll();
    }

    // Protected admin-only example
    @PostMapping("/admin")
    public ResponseEntity<Product> create(@RequestBody Product p) {
        return ResponseEntity.ok(repo.save(p));
    }
}
