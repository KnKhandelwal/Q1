package com.example.threea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThreeAApplication {
    public static void main(String[] args) {
        SpringApplication.run(ThreeAApplication.class, args);
    }
}
