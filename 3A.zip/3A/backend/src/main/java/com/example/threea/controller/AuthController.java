package com.example.threea.controller;

import com.example.threea.model.AppUser;
import com.example.threea.repo.UserRepository;
import com.example.threea.security.JwtService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = {"http://localhost:5173","http://localhost:3000"})
public class AuthController {

    record RegisterRequest(@NotBlank @Size(min=3,max=30) String username,
                           @NotBlank @Size(min=6,max=100) String password) {}
    record LoginRequest(@NotBlank String username, @NotBlank String password) {}
    record AuthResponse(String token, String username, String roles) {}

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authManager;
    private final JwtService jwtService;

    public AuthController(UserRepository users, PasswordEncoder encoder, AuthenticationManager authManager, JwtService jwtService) {
        this.users = users;
        this.encoder = encoder;
        this.authManager = authManager;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (users.existsByUsername(req.username())) {
            return ResponseEntity.badRequest().body(Map.of("error", "Username already exists"));
        }
        AppUser u = new AppUser(req.username(), encoder.encode(req.password()), "ROLE_USER");
        users.save(u);
        Map<String,Object> extra = new HashMap<>();
        extra.put("roles", u.getRoles());
        String token = jwtService.generateToken(u.getUsername(), extra);
        return ResponseEntity.ok(new AuthResponse(token, u.getUsername(), u.getRoles()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        Authentication auth = authManager.authenticate(new UsernamePasswordAuthenticationToken(req.username(), req.password()));
        var user = users.findByUsername(req.username()).orElseThrow();
        Map<String,Object> extra = new HashMap<>();
        extra.put("roles", user.getRoles());
        String token = jwtService.generateToken(user.getUsername(), extra);
        return ResponseEntity.ok(new AuthResponse(token, user.getUsername(), user.getRoles()));
    }
}
