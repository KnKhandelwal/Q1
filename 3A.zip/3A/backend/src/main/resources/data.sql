
INSERT INTO PRODUCT (id, name, brand, category, thumbnail, description, price, mrp, stock) VALUES
  (1, 'Laptop 14"', 'ZenTek', 'Computers', 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8', 'Portable laptop with 16GB RAM', 58999, 69999, 10),
  (2, 'Gaming Mouse', 'ProClick', 'Peripherals', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9', 'Lightweight gaming mouse', 1999, 2999, 80),
  (3, 'Bluetooth Speaker', 'BoomBox', 'Audio', 'https://images.unsplash.com/photo-1518449363931-4f033a6fac2c', 'Loud and clear sound', 3499, 4999, 40);
