# 3A — JWT Auth + Roles (Spring Boot + React)

A minimal full-stack example with **user registration & login**, **JWT** authentication, **role-based authorization**, and a small product catalog.

## Features
- Register & Login returning JWT
- Spring Security with stateless JWT
- Protected endpoints:
  - `/api/user/me` → requires USER or ADMIN
  - `/api/admin/**` → requires ADMIN
- Public products listing at `/api/products`
- React frontend with Login / Register pages, axios interceptor for JWT
- H2 in-memory DB, sample users: `admin/admin123`, `user/user123`

## Run

### Backend
```bash
cd backend
mvn spring-boot:run
```
- Swagger UI: `http://localhost:8080/swagger-ui.html`
- H2 Console: `http://localhost:8080/h2-console` (JDBC: `jdbc:h2:mem:threea`)

### Frontend
```bash
cd frontend
npm install
npm run dev
```
- App: `http://localhost:5173`

## Notes
- JWT secret & expiry configured in `application.properties`
- Token is stored in `localStorage` as `3a.token`
- To test admin route in UI, login with `admin/admin123` then open `/admin`
