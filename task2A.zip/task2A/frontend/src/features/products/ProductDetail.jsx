import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '../../api/client'
import { useCart } from '../cart/store'

export default function ProductDetail(){
  const { id } = useParams()
  const [p, setP] = useState(null)
  const [qty, setQty] = useState(1)
  const nav = useNavigate()
  const { add } = useCart()

  useEffect(() => { api.get(`/products/${id}`).then(r => setP(r.data)) }, [id])
  if (!p) return null

  return (
    <div className="layout">
      <div className="panel">
        <img src={p.imageUrl || 'https://via.placeholder.com/600x400'} alt="" style={{width:'100%',height:360,objectFit:'cover',borderRadius:12,background:'#222'}} />
        <h2>{p.name}</h2>
        <div className="badge">{p.category}</div>
        <p style={{color:'var(--muted)'}}>{p.description}</p>
      </div>
      <div className="panel">
        <div className="price">₹{Number(p.price).toFixed(2)}</div>
        <div className="line">
          <div>Quantity</div>
          <input className="input" type="number" min="1" max={p.stock} value={qty} onChange={e => setQty(parseInt(e.target.value || 1))} />
        </div>
        <div className="line"><div>Stock</div><div>{p.stock}</div></div>
        <button className="button" onClick={() => add(p, qty)}>Add to Cart</button>
        <button className="button ghost" style={{marginTop:8}} onClick={() => nav('/cart')}>View Cart</button>
      </div>
    </div>
  )
}