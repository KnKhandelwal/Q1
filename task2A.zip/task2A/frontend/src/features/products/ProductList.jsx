import { useEffect, useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import api from '../../api/client'
import { useCart } from '../cart/store'

export default function ProductList(){
  const [products, setProducts] = useState([])
  const [q, setQ] = useState('')
  const [category, setCategory] = useState('')
  const { add } = useCart()
  const [params, setParams] = useSearchParams()

  useEffect(() => {
    const qp = params.get('q') || ''
    const cp = params.get('category') || ''
    setQ(qp); setCategory(cp)
    api.get('/products', { params: { q: qp, category: cp } }).then(r => setProducts(r.data))
  }, [params])

  const cats = useMemo(() => Array.from(new Set(products.map(p => p.category))), [products])

  function search(){
    const p = {}
    if (q) p.q = q
    if (category) p.category = category
    setParams(p)
  }

  return (
    <div>
      <div className="search">
        <input className="input" placeholder="Search products" value={q} onChange={e => setQ(e.target.value)} />
        <select className="select" value={category} onChange={e => setCategory(e.target.value)}>
          <option value="">All</option>
          {cats.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button className="button" onClick={search}>Search</button>
      </div>
      <div className="grid" style={{marginTop:16}}>
        {products.map(p => (
          <div className="card" key={p.id}>
            <img src={p.imageUrl || 'https://via.placeholder.com/400x300'} alt="" />
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <Link to={`/products/${p.id}`} className="name">{p.name}</Link>
              <span className="badge">{p.category}</span>
            </div>
            <div className="price">₹{Number(p.price).toFixed(2)}</div>
            <button className="button" onClick={() => add(p,1)}>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  )
}