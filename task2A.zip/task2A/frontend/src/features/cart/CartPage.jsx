import { useCart } from './store'

export default function CartPage(){
  const { items, setQty, remove, total, clear } = useCart()
  return (
    <div className="panel">
      <h2>Cart</h2>
      {items.length === 0 ? <div style={{color:'var(--muted)'}}>Your cart is empty</div> :
        <div>
          {items.map(i => (
            <div className="line" key={i.id}>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <img src={i.imageUrl || 'https://via.placeholder.com/60'} alt="" style={{width:60,height:40,objectFit:'cover',borderRadius:8}} />
                <div>{i.name}</div>
              </div>
              <div>₹{Number(i.price).toFixed(2)}</div>
              <input className="input" type="number" min="1" value={i.qty} onChange={e => setQty(i.id, parseInt(e.target.value || 1))} style={{width:80}} />
              <div>₹{(Number(i.price)*i.qty).toFixed(2)}</div>
              <button className="button ghost" onClick={() => remove(i.id)}>Remove</button>
            </div>
          ))}
          <div className="line total"><div>Total</div><div>₹{total().toFixed(2)}</div></div>
          <button className="button" onClick={clear}>Clear Cart</button>
        </div>
      }
    </div>
  )
}