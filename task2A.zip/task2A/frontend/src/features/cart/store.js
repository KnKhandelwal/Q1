import { create } from 'zustand'

export const useCart = create((set, get) => ({
  items: [],
  add: (p, qty = 1) => {
    const items = [...get().items]
    const idx = items.findIndex(i => i.id === p.id)
    if (idx >= 0) items[idx] = { ...items[idx], qty: items[idx].qty + qty }
    else items.unshift({ id: p.id, name: p.name, price: p.price, imageUrl: p.imageUrl, qty })
    set({ items })
  },
  remove: (id) => set({ items: get().items.filter(i => i.id !== id) }),
  setQty: (id, qty) => {
    if (qty <= 0) return set({ items: get().items.filter(i => i.id !== id) })
    set({ items: get().items.map(i => i.id === id ? { ...i, qty } : i) })
  },
  clear: () => set({ items: [] }),
  total: () => get().items.reduce((s, i) => s + i.price * i.qty, 0),
  totalCount: () => get().items.reduce((s, i) => s + i.qty, 0)
}))