import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom'
import ProductList from './features/products/ProductList.jsx'
import ProductDetail from './features/products/ProductDetail.jsx'
import CartPage from './features/cart/CartPage.jsx'
import { useCart } from './features/cart/store.js'

export default function App(){
  const { totalCount } = useCart()
  const nav = useNavigate()
  const loc = useLocation()
  return (
    <div className="container">
      <header className="header">
        <div className="brand"><Link to="/">task2A</Link></div>
        <div className="nav">
          <Link to="/">Products</Link>
          <Link to="/cart" className="badge">Cart {totalCount() > 0 ? `(${totalCount()})` : ''}</Link>
        </div>
      </header>
      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/products/:id" element={<ProductDetail />} />
        <Route path="/cart" element={<CartPage />} />
      </Routes>
    </div>
  )
}