package com.example.task2a.product;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class ProductService {
    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    public List<Product> list(String q, String category) {
        if (q != null && !q.isBlank()) return repo.findByNameContainingIgnoreCase(q);
        if (category != null && !category.isBlank()) return repo.findByCategoryIgnoreCase(category);
        return repo.findAll();
    }

    public Product get(Long id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
    }
}