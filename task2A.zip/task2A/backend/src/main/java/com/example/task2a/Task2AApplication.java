package com.example.task2a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task2AApplication {
    public static void main(String[] args) {
        SpringApplication.run(Task2AApplication.class, args);
    }
}