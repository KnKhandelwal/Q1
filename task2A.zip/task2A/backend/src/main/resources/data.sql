INSERT INTO products (id, name, description, price, category, image_url, stock) VALUES
(1,'Wireless Headphones','Over-ear Bluetooth headphones with noise isolation', 3499.00,'Audio','https://images.unsplash.com/photo-1518443881190-905f7e9a3578', 25),
(2,'Mechanical Keyboard','RGB backlit 87-key mechanical keyboard', 4999.00,'Peripherals','https://images.unsplash.com/photo-1519681393784-d120267933ba', 40),
(3,'Smartwatch','Fitness tracking, heart rate monitor, GPS', 6999.00,'Wearables','https://images.unsplash.com/photo-1511707171634-5f897ff02aa9', 18),
(4,'USB-C Hub','7-in-1 USB-C hub with HDMI and SD reader', 2499.00,'Accessories','https://images.unsplash.com/photo-1517336714731-489689fd1ca8', 60),
(5,'4K Monitor','27-inch IPS 4K UHD monitor', 21999.00,'Displays','https://images.unsplash.com/photo-1517336714731-489689fd1ca8', 12),
(6,'Gaming Mouse','Ergonomic mouse with adjustable DPI', 1999.00,'Peripherals','https://images.unsplash.com/photo-1584634731339-676f9020f7eb', 55);