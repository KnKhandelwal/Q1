# task2A

Backend: Spring Boot 3, H2. Endpoints: GET /api/products, GET /api/products/{id}
Frontend: React + Vite + Axios + React Router + Zustand

Run
Backend
cd backend
mvn spring-boot:run

Frontend
cd frontend
npm i
npm run dev