# Bank App (Spring Boot + Thymeleaf + Maven)

A simple banking web application to demonstrate CRUD, services, transactions,
and Thymeleaf views. **No security or testing** included by design.

## Features
- Manage Customers (create/list)
- Create Accounts for Customers
- Deposit / Withdraw
- View Account details and Transaction history

## Tech
- Spring Boot 3.x, Java 17, Maven
- Spring Web, Thymeleaf, Spring Data JPA
- H2 in-memory DB

## Run
```bash
mvn spring-boot:run
# then open http://localhost:8080
```

## H2 Console
- URL: `/h2-console`
- JDBC URL: `jdbc:h2:mem:bankdb`
- User: `sa`
- Password: (empty)
