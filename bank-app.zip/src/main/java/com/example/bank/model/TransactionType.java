package com.example.bank.model;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW
}
