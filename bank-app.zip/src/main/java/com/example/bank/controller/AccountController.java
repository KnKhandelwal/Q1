package com.example.bank.controller;

import com.example.bank.model.Account;
import com.example.bank.service.AccountService;
import com.example.bank.service.CustomerService;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@Controller
@RequestMapping("/accounts")
@Validated
public class AccountController {

    private final AccountService accountService;
    private final CustomerService customerService;

    public AccountController(AccountService accountService, CustomerService customerService) {
        this.accountService = accountService;
        this.customerService = customerService;
    }

    @PostMapping("/create/{customerId}")
    public String create(@PathVariable Long customerId) {
        accountService.createForCustomer(customerId);
        return "redirect:/customers";
    }

    @GetMapping("/{accountId}")
    public String view(@PathVariable Long accountId, Model model) {
        Account acc = accountService.getById(accountId);
        model.addAttribute("account", acc);
        model.addAttribute("transactions", accountService.getTransactions(accountId));
        return "accounts/view";
    }

    @GetMapping("/{accountId}/deposit")
    public String depositForm(@PathVariable Long accountId, Model model) {
        model.addAttribute("accountId", accountId);
        return "accounts/deposit";
    }

    @PostMapping("/{accountId}/deposit")
    public String deposit(@PathVariable Long accountId,
                          @RequestParam @NotNull @DecimalMin(value = "0.01") BigDecimal amount,
                          @RequestParam(required = false) String description) {
        accountService.deposit(accountId, amount, description);
        return "redirect:/accounts/" + accountId;
    }

    @GetMapping("/{accountId}/withdraw")
    public String withdrawForm(@PathVariable Long accountId, Model model) {
        model.addAttribute("accountId", accountId);
        return "accounts/withdraw";
    }

    @PostMapping("/{accountId}/withdraw")
    public String withdraw(@PathVariable Long accountId,
                           @RequestParam @NotNull @DecimalMin(value = "0.01") BigDecimal amount,
                           @RequestParam(required = false) String description) {
        accountService.withdraw(accountId, amount, description);
        return "redirect:/accounts/" + accountId;
    }
}
