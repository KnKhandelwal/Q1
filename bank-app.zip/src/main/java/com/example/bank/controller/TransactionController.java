package com.example.bank.controller;

import com.example.bank.service.AccountService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/transactions")
public class TransactionController {

    private final AccountService accountService;

    public TransactionController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/account/{accountId}")
    public String history(@PathVariable Long accountId, Model model) {
        model.addAttribute("account", accountService.getById(accountId));
        model.addAttribute("transactions", accountService.getTransactions(accountId));
        return "transactions/history";
    }
}
