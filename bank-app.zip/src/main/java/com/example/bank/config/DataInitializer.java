package com.example.bank.config;

import com.example.bank.model.Customer;
import com.example.bank.service.AccountService;
import com.example.bank.service.CustomerService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seed(CustomerService customerService, AccountService accountService) {
        return args -> {
            Customer alice = customerService.create(new Customer("Alice", "alice@example.com"));
            Customer bob = customerService.create(new Customer("Bob", "bob@example.com"));

            var a1 = accountService.createForCustomer(alice.getId());
            var b1 = accountService.createForCustomer(bob.getId());

            accountService.deposit(a1.getId(), new BigDecimal("500.00"), "Initial deposit");
            accountService.deposit(b1.getId(), new BigDecimal("1000.00"), "Initial deposit");
            accountService.withdraw(b1.getId(), new BigDecimal("150.00"), "ATM withdrawal");
        };
    }
}
