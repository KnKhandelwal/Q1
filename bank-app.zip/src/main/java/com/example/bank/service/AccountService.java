package com.example.bank.service;

import com.example.bank.exception.InsufficientFundsException;
import com.example.bank.model.Account;
import com.example.bank.model.Customer;
import com.example.bank.model.Transaction;
import com.example.bank.model.TransactionType;
import com.example.bank.repository.AccountRepository;
import com.example.bank.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.List;

@Service
public class AccountService {

    private final AccountRepository accountRepository;
    private final CustomerService customerService;
    private final TransactionRepository transactionRepository;
    private final SecureRandom random = new SecureRandom();

    public AccountService(AccountRepository accountRepository,
                          CustomerService customerService,
                          TransactionRepository transactionRepository) {
        this.accountRepository = accountRepository;
        this.customerService = customerService;
        this.transactionRepository = transactionRepository;
    }

    public Account getById(Long id) {
        return accountRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Account not found"));
    }

    public List<Transaction> getTransactions(Long accountId) {
        return transactionRepository.findByAccountIdOrderByTimestampDesc(accountId);
    }

    @Transactional
    public Account createForCustomer(Long customerId) {
        Customer c = customerService.getById(customerId);
        String accNo = generateUniqueAccountNumber();
        Account acc = new Account(accNo, c);
        return accountRepository.save(acc);
    }

    @Transactional
    public void deposit(Long accountId, BigDecimal amount, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        Account acc = getById(accountId);
        acc.setBalance(acc.getBalance().add(amount));
        accountRepository.save(acc);
        Transaction tx = new Transaction(acc, TransactionType.DEPOSIT, amount, description);
        transactionRepository.save(tx);
    }

    @Transactional
    public void withdraw(Long accountId, BigDecimal amount, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        Account acc = getById(accountId);
        if (acc.getBalance().compareTo(amount) < 0) {
            throw new InsufficientFundsException("Insufficient funds: balance " + acc.getBalance());
        }
        acc.setBalance(acc.getBalance().subtract(amount));
        accountRepository.save(acc);
        Transaction tx = new Transaction(acc, TransactionType.WITHDRAW, amount, description);
        transactionRepository.save(tx);
    }

    private String generateUniqueAccountNumber() {
        // 12-digit numeric account number generator; ensure uniqueness
        String accNo;
        do {
            long num = Math.abs(random.nextLong()) % 1_000_000_000_000L;
            accNo = String.format("%012d", num);
        } while (accountRepository.existsByAccountNumber(accNo));
        return accNo;
    }
}
