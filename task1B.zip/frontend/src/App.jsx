import { useState,useEffect } from 'react'
import axios from './api/client'
import UserForm from './features/users/UserForm'
import UserList from './features/users/UserList'
import UserView from './features/users/UserView'
export default function App(){
 const [users,setUsers]=useState([])
 const [selected,setSelected]=useState(null)
 const [editing,setEditing]=useState(false)
 useEffect(()=>{load()},[])
 function load(){axios.get('/users').then(r=>setUsers(r.data))}
 function handleSave(u){if(u.id){axios.put('/users/'+u.id,u).then(load)} else {axios.post('/users',u).then(load)} setEditing(false);setSelected(null)}
 function handleDelete(id){axios.delete('/users/'+id).then(load)}
 return <div className='container'>
  <h1>User Profiles</h1>
  {editing?<UserForm user={selected} onSave={handleSave} onCancel={()=>{setEditing(false);setSelected(null)}}/>:
   selected?<UserView user={selected} onBack={()=>setSelected(null)} onEdit={()=>setEditing(true)} onDelete={()=>handleDelete(selected.id)}/>:
   <UserList users={users} onSelect={setSelected} onAdd={()=>setEditing(true)}/>}
 </div>
}