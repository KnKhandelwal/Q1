export default function UserList({users,onSelect,onAdd}){
 return <div><button className='btn' onClick={onAdd}>Add User</button><ul className='list'>{users.map(u=>(<li key={u.id} onClick={()=>onSelect(u)}>{u.name} - {u.email}</li>))}</ul></div>
}