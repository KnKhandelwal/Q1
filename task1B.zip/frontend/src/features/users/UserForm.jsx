import { useState } from 'react'
export default function UserForm({user,onSave,onCancel}){
 const [name,setName]=useState(user?user.name:'')
 const [email,setEmail]=useState(user?user.email:'')
 const [password,setPassword]=useState(user?user.password:'')
 const [errors,setErrors]=useState({})
 function validate(){
  let e={}
  if(!name||name.length<2)e.name='Name must be at least 2 characters'
  if(!/^[^@]+@[^@]+\.[^@]+$/.test(email))e.email='Invalid email'
  if(!password||password.length<6)e.password='Password must be at least 6 characters'
  setErrors(e);return Object.keys(e).length===0
 }
 function submit(ev){ev.preventDefault();if(validate())onSave({...user,name,email,password})}
 return <form onSubmit={submit} className='form'>
  <input value={name} onChange={e=>setName(e.target.value)} placeholder='Name'/>{errors.name&&<div className='error'>{errors.name}</div>}
  <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='Email'/>{errors.email&&<div className='error'>{errors.email}</div>}
  <input type='password' value={password} onChange={e=>setPassword(e.target.value)} placeholder='Password'/>{errors.password&&<div className='error'>{errors.password}</div>}
  <div className='actions'><button type='submit' className='btn'>Save</button><button type='button' className='btn' onClick={onCancel}>Cancel</button></div>
 </form>
}