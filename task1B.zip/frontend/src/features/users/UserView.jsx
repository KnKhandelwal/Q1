export default function UserView({user,onBack,onEdit,onDelete}){
 return <div className='view'><h2>{user.name}</h2><p>{user.email}</p><button className='btn' onClick={onEdit}>Edit</button><button className='btn' onClick={onBack}>Back</button><button className='btn danger' onClick={onDelete}>Delete</button></div>
}