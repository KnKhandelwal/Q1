import React, { useState } from 'react'
import { Card, Form, Button, Alert } from 'react-bootstrap'
import api from '../services/api'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const submit = async (e) => {
    e.preventDefault()
    try {
      const { data } = await api.post('/api/auth/login', { email, password })
      localStorage.setItem('token', data.token)
      window.location.href = '/'
    } catch (e) { setErr('Invalid credentials') }
  }
  return (
    <Card className="p-4">
      <h4 className="mb-3">Sign in</h4>
      {err && <Alert variant="danger">{err}</Alert>}
      <Form onSubmit={submit}>
        <Form.Group className="mb-3">
          <Form.Label>Email</Form.Label>
          <Form.Control value={email} onChange={e=>setEmail(e.target.value)} type="email" required/>
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Password</Form.Label>
          <Form.Control value={password} onChange={e=>setPassword(e.target.value)} type="password" required/>
        </Form.Group>
        <Button type="submit" className="btn-rounded">Login</Button>
      </Form>
    </Card>
  )
}
