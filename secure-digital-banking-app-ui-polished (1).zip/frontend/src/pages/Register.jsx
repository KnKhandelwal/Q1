import React, { useState } from 'react'
import { Card, Form, Button, Alert } from 'react-bootstrap'
import api from '../services/api'

export default function Register(){
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')
  const submit = async (e) => {
    e.preventDefault()
    try {
      const { data } = await api.post('/api/auth/register', { fullName, email, password })
      localStorage.setItem('token', data.token)
      setMsg('Registration successful!')
    } catch (e) { setMsg('Registration failed') }
  }
  return (
    <Card className="p-4">
      <h4 className="mb-3">Create account</h4>
      {msg && <Alert variant="info">{msg}</Alert>}
      <Form onSubmit={submit}>
        <Form.Group className="mb-3">
          <Form.Label>Full name</Form.Label>
          <Form.Control value={fullName} onChange={e=>setFullName(e.target.value)} required/>
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Email</Form.Label>
          <Form.Control value={email} onChange={e=>setEmail(e.target.value)} type="email" required/>
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Password</Form.Label>
          <Form.Control value={password} onChange={e=>setPassword(e.target.value)} type="password" required/>
        </Form.Group>
        <Button type="submit" className="btn-rounded">Register</Button>
      </Form>
    </Card>
  )
}
