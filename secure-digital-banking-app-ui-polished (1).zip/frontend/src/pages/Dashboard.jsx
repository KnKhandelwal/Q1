import React, { useEffect, useState } from 'react'
import { Card, Row, Col, Form, Button, Table, Alert } from 'react-bootstrap'
import api from '../services/api'

export default function Dashboard(){
  const [acct, setAcct] = useState(null)
  const [amount, setAmount] = useState('')
  const [toAcc, setToAcc] = useState('')
  const [txns, setTxns] = useState([])
  const [msg, setMsg] = useState('')

  const load = async () => {
    try { const { data } = await api.get('/api/account/me'); setAcct(data) } catch {}
    try { const { data } = await api.get('/api/account/transactions'); setTxns(data) } catch {}
  }
  useEffect(() => { load() }, [])

  const doDeposit = async () => { await api.post('/api/account/deposit', { amount: Number(amount) }); setMsg('Deposited'); load() }
  const doWithdraw = async () => { await api.post('/api/account/withdraw', { amount: Number(amount) }); setMsg('Withdrawn'); load() }
  const doTransfer = async () => { await api.post('/api/account/transfer', { toAccountNumber: toAcc, amount: Number(amount) }); setMsg('Transferred'); load() }

  if (!acct) return <Alert variant="warning">Login required. Use admin: admin@bank.com / Admin@123</Alert>

  return (
    <>
      <Row className="mb-4">
        <Col md={4}>
          <Card className="p-3">
            <h5>Account</h5>
            <div>Number: <b>{acct.accountNumber}</b></div>
            <div>Owner: <b>{acct.owner}</b></div>
            <div className="display-6 mt-2">₹ {acct.balance}</div>
          </Card>
        </Col>
        <Col md={8}>
          <Card className="p-3">
            <h5>Actions</h5>
            {msg && <Alert className="mt-2" onClose={()=>setMsg('')} dismissible>{msg}</Alert>}
            <Row className="g-2">
              <Col md={4}><Form.Control placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} /></Col>
              <Col md={4}><Form.Control placeholder="To Account (transfer)" value={toAcc} onChange={e=>setToAcc(e.target.value)} /></Col>
              <Col md={4} className="d-flex gap-2">
                <Button onClick={doDeposit}>Deposit</Button>
                <Button variant="secondary" onClick={doWithdraw}>Withdraw</Button>
                <Button variant="outline-primary" onClick={doTransfer}>Transfer</Button>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
      <Card className="p-3">
        <h5>Transactions</h5>
        <Table striped responsive className="mt-3">
          <thead><tr><th>ID</th><th>Type</th><th>Amount</th><th>At</th><th>Ref</th></tr></thead>
          <tbody>
            {txns.map(t => <tr key={t.id}><td>{t.id}</td><td>{t.type}</td><td>{t.amount}</td><td>{new Date(t.at).toLocaleString()}</td><td>{t.ref}</td></tr>)}
          </tbody>
        </Table>
      </Card>
    </>
  )
}
