import React, { useEffect, useState } from 'react'
import { Card, Table, Row, Col } from 'react-bootstrap'
import api from '../services/api'

export default function Admin(){
  const [customers, setCustomers] = useState([])
  const [accounts, setAccounts] = useState([])
  const [transactions, setTransactions] = useState([])
  const [audits, setAudits] = useState([])
  useEffect(() => {
    (async () => {
      try {
        setCustomers((await api.get('/api/admin/customers')).data)
        setAccounts((await api.get('/api/admin/accounts')).data)
        setTransactions((await api.get('/api/admin/transactions')).data)
        setAudits((await api.get('/api/admin/audits')).data)
      } catch {}
    })()
  }, [])

  return (
    <Row className="g-3">
      <Col md={6}>
        <Card className="p-3"><h5>Customers</h5>
          <Table size="sm" responsive><thead><tr><th>ID</th><th>Name</th><th>Email</th></tr></thead>
          <tbody>{customers.map(c => <tr key={c.id}><td>{c.id}</td><td>{c.fullName}</td><td>{c.user?.email}</td></tr>)}</tbody></Table>
        </Card>
      </Col>
      <Col md={6}>
        <Card className="p-3"><h5>Accounts</h5>
          <Table size="sm" responsive><thead><tr><th>ID</th><th>Number</th><th>Balance</th></tr></thead>
          <tbody>{accounts.map(a => <tr key={a.id}><td>{a.id}</td><td>{a.accountNumber}</td><td>{a.balance}</td></tr>)}</tbody></Table>
        </Card>
      </Col>
      <Col md={6}>
        <Card className="p-3"><h5>Transactions</h5>
          <Table size="sm" responsive><thead><tr><th>ID</th><th>Acc</th><th>Type</th><th>Amt</th></tr></thead>
          <tbody>{transactions.map(t => <tr key={t.id}><td>{t.id}</td><td>{t.account?.accountNumber}</td><td>{t.type}</td><td>{t.amount}</td></tr>)}</tbody></Table>
        </Card>
      </Col>
      <Col md={6}>
        <Card className="p-3"><h5>Audit Logs</h5>
          <Table size="sm" responsive><thead><tr><th>ID</th><th>Actor</th><th>Action</th><th>At</th></tr></thead>
          <tbody>{audits.map(a => <tr key={a.id}><td>{a.id}</td><td>{a.actor}</td><td>{a.action}</td><td>{new Date(a.at).toLocaleString()}</td></tr>)}</tbody></Table>
        </Card>
      </Col>
    </Row>
  )
}
