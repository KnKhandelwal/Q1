package com.example.bank.service;

import com.example.bank.domain.*;
import com.example.bank.repo.AccountRepository;
import com.example.bank.repo.CustomerRepository;
import com.example.bank.repo.TransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class AccountServiceTest {
    private AccountRepository accountRepo;
    private CustomerRepository customerRepo;
    private TransactionRepository txnRepo;
    private AccountService service;
    private Account account;

    @BeforeEach
    void setup(){
        accountRepo = Mockito.mock(AccountRepository.class);
        customerRepo = Mockito.mock(CustomerRepository.class);
        txnRepo = Mockito.mock(TransactionRepository.class);
        service = new AccountService(accountRepo, customerRepo, txnRepo);
        Customer c = new Customer("John Doe", null);
        account = new Account("123456789012", c);
        when(accountRepo.save(any(Account.class))).thenAnswer(inv -> inv.getArgument(0));
        when(txnRepo.save(any(Transaction.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    @Test
    void depositIncreasesBalance(){
        service.deposit(account, new BigDecimal("100.00"), "test");
        assertEquals(new BigDecimal("100.00"), account.getBalance());
        verify(txnRepo, times(1)).save(any(Transaction.class));
    }

    @Test
    void withdrawInsufficientFunds(){
        assertThrows(IllegalArgumentException.class, () -> service.withdraw(account, new BigDecimal("50.00"), "test"));
    }
}
