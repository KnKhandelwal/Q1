package com.example.bank.controller;

import com.example.bank.dto.AuthDtos.*;
import com.example.bank.service.AuthService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class AuthControllerTest {
    @Test
    void registerReturnsOk() throws Exception {
        AuthService svc = Mockito.mock(AuthService.class);
        Mockito.when(svc.register(Mockito.any())).thenReturn("token");
        MockMvc mvc = MockMvcBuilders.standaloneSetup(new AuthController(svc)).build();
        String body = "{"fullName":"Jane","email":"j@e.com","password":"p"}";
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk());
    }
}
