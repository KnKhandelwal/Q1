package com.example.bank.controller;

import com.example.bank.domain.Account;
import com.example.bank.domain.Customer;
import com.example.bank.domain.Transaction;
import com.example.bank.dto.AccountDtos.AccountRes;
import com.example.bank.repo.*;
import com.example.bank.service.AuditService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {
    private final CustomerRepository customers;
    private final AccountRepository accounts;
    private final TransactionRepository transactions;
    private final AuditLogRepository audits;
    private final AuditService auditService;

    public AdminController(CustomerRepository customers, AccountRepository accounts, TransactionRepository transactions,
                           AuditLogRepository audits, AuditService auditService){
        this.customers=customers; this.accounts=accounts; this.transactions=transactions; this.audits=audits; this.auditService=auditService;
    }

    @GetMapping("/customers") public List<Customer> allCustomers(){ return customers.findAll(); }
    @GetMapping("/accounts") public List<Account> allAccounts(){ return accounts.findAll(); }
    @GetMapping("/transactions") public List<Transaction> allTransactions(){ return transactions.findAll(); }
    @GetMapping("/audits") public Object allAudits(){ return audits.findAll(); }

    @DeleteMapping("/customers/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id){
        customers.deleteById(id);
        auditService.log("ADMIN", "DELETE_CUSTOMER", "id="+id);
        return ResponseEntity.noContent().build();
    }
}
