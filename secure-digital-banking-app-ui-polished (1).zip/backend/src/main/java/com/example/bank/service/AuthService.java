package com.example.bank.service;

import com.example.bank.domain.*;
import com.example.bank.dto.AuthDtos.*;
import com.example.bank.repo.*;
import com.example.bank.security.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.Set;

@Service
public class AuthService {
    private final UserRepository users;
    private final CustomerRepository customers;
    private final AccountService accountService;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authManager;
    private final JwtUtil jwt;

    public AuthService(UserRepository users, CustomerRepository customers, AccountService accountService,
                       PasswordEncoder encoder, AuthenticationManager authManager, JwtUtil jwt) {
        this.users = users; this.customers = customers; this.accountService = accountService;
        this.encoder = encoder; this.authManager = authManager; this.jwt = jwt;
    }

    @Transactional
    public String register(RegisterReq req){
        if (users.existsByEmail(req.email())) throw new IllegalArgumentException("Email already registered");
        User u = new User(req.email(), encoder.encode(req.password()), Set.of(Role.CUSTOMER));
        users.save(u);
        Customer c = new Customer(req.fullName(), u);
        customers.save(c);
        accountService.createPrimaryAccount(c);
        return jwt.generate(u.getEmail(), Map.of("role","CUSTOMER"));
    }

    public String login(LoginReq req){
        Authentication auth = authManager.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        var principal = auth.getName();
        var user = users.findByEmail(principal).orElseThrow();
        String role = user.getRoles().stream().findFirst().orElse(Role.CUSTOMER).name();
        return jwt.generate(principal, Map.of("role", role));
    }
}
