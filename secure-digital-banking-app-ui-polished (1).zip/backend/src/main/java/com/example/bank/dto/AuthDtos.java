package com.example.bank.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
public class AuthDtos {
    public record RegisterReq(@NotBlank String fullName, @Email String email, @NotBlank String password) {}
    public record LoginReq(@Email String email, @NotBlank String password) {}
    public record AuthRes(String token, String role) {}
}
