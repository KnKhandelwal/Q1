package com.example.bank.service;

import com.example.bank.domain.*;
import com.example.bank.repo.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;

@Service
public class AccountService {
    private final AccountRepository accountRepo;
    private final CustomerRepository customerRepo;
    private final TransactionRepository txnRepo;

    public AccountService(AccountRepository accountRepo, CustomerRepository customerRepo, TransactionRepository txnRepo){
        this.accountRepo = accountRepo; this.customerRepo = customerRepo; this.txnRepo = txnRepo;
    }

    public static String generateAccountNumber() {
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i=0; i<12; i++) sb.append(r.nextInt(10));
        return sb.toString();
    }

    public Account createPrimaryAccount(Customer c){
        Account a = new Account(generateAccountNumber(), c);
        return accountRepo.save(a);
    }

    public Optional<Account> byNumber(String acc){ return accountRepo.findByAccountNumber(acc); }

    public List<Account> all(){ return accountRepo.findAll(); }

    @Transactional
    public Account deposit(Account a, BigDecimal amount, String ref){
        a.setBalance(a.getBalance().add(amount));
        accountRepo.save(a);
        txnRepo.save(new Transaction(a, TxnType.DEPOSIT, amount, ref));
        return a;
    }

    @Transactional
    public Account withdraw(Account a, BigDecimal amount, String ref){
        if (a.getBalance().compareTo(amount) < 0) throw new IllegalArgumentException("Insufficient funds");
        a.setBalance(a.getBalance().subtract(amount));
        accountRepo.save(a);
        txnRepo.save(new Transaction(a, TxnType.WITHDRAW, amount, ref));
        return a;
    }

    @Transactional
    public void transfer(Account from, Account to, BigDecimal amount, String ref){
        if (from.getId().equals(to.getId())) throw new IllegalArgumentException("Same account");
        withdraw(from, amount, ref);
        deposit(to, amount, ref);
        txnRepo.save(new Transaction(from, TxnType.TRANSFER_OUT, amount, "to "+to.getAccountNumber()));
        txnRepo.save(new Transaction(to, TxnType.TRANSFER_IN, amount, "from "+from.getAccountNumber()));
    }
}
