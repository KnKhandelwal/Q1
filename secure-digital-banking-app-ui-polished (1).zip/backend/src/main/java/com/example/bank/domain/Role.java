package com.example.bank.domain;
public enum Role { CUSTOMER, ADMIN }
