package com.example.bank.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
public class Transaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Account account;

    @Enumerated(EnumType.STRING)
    private TxnType type;

    private BigDecimal amount;
    private Instant timestamp = Instant.now();
    private String reference;

    public Transaction() {}
    public Transaction(Account account, TxnType type, BigDecimal amount, String reference) {
        this.account = account; this.type = type; this.amount = amount; this.reference = reference;
    }
    public Long getId() { return id; }
    public Account getAccount() { return account; }
    public TxnType getType() { return type; }
    public BigDecimal getAmount() { return amount; }
    public Instant getTimestamp() { return timestamp; }
    public String getReference() { return reference; }
}
