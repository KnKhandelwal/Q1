package com.example.bank.dto;

import java.math.BigDecimal;
public class AccountDtos {
    public record AccountRes(String accountNumber, BigDecimal balance, String owner) {}
    public record MoneyReq(BigDecimal amount) {}
    public record TransferReq(String toAccountNumber, BigDecimal amount) {}
}
