package com.example.bank.controller;

import com.example.bank.domain.*;
import com.example.bank.dto.AccountDtos.*;
import com.example.bank.dto.TransactionDtos.TxnRes;
import com.example.bank.repo.*;
import com.example.bank.service.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

@RestController @RequestMapping("/api/account")
@PreAuthorize("hasRole('CUSTOMER') or hasRole('ADMIN')")
public class AccountController {
    private final UserRepository users;
    private final CustomerRepository customers;
    private final AccountRepository accounts;
    private final TransactionRepository txns;
    private final AccountService accountService;
    private final AuditService audit;

    public AccountController(UserRepository users, CustomerRepository customers, AccountRepository accounts,
                             TransactionRepository txns, AccountService accountService, AuditService audit){
        this.users=users; this.customers=customers; this.accounts=accounts; this.txns=txns; this.accountService=accountService; this.audit=audit;
    }

    @GetMapping("/me")
    public ResponseEntity<AccountRes> myAccount(@AuthenticationPrincipal UserDetails principal){
        User u = users.findByEmail(principal.getUsername()).orElseThrow();
        Customer c = customers.findAll().stream().filter(cc -> cc.getUser().getId().equals(u.getId())).findFirst().orElseThrow();
        Account a = accounts.findAll().stream().filter(ac -> ac.getCustomer().getId().equals(c.getId())).findFirst().orElseThrow();
        return ResponseEntity.ok(new AccountRes(a.getAccountNumber(), a.getBalance(), c.getFullName()));
    }

    @PostMapping("/deposit")
    public ResponseEntity<AccountRes> deposit(@AuthenticationPrincipal UserDetails principal, @RequestBody MoneyReq req){
        Account a = accounts.findAll().stream().filter(ac -> ac.getCustomer().getUser().getEmail().equals(principal.getUsername())).findFirst().orElseThrow();
        accountService.deposit(a, req.amount(), "deposit");
        audit.log(principal.getUsername(), "DEPOSIT", "amount="+req.amount());
        return ResponseEntity.ok(new AccountRes(a.getAccountNumber(), a.getBalance(), a.getCustomer().getFullName()));
    }

    @PostMapping("/withdraw")
    public ResponseEntity<AccountRes> withdraw(@AuthenticationPrincipal UserDetails principal, @RequestBody MoneyReq req){
        Account a = accounts.findAll().stream().filter(ac -> ac.getCustomer().getUser().getEmail().equals(principal.getUsername())).findFirst().orElseThrow();
        accountService.withdraw(a, req.amount(), "withdraw");
        audit.log(principal.getUsername(), "WITHDRAW", "amount="+req.amount());
        return ResponseEntity.ok(new AccountRes(a.getAccountNumber(), a.getBalance(), a.getCustomer().getFullName()));
    }

    @PostMapping("/transfer")
    public ResponseEntity<String> transfer(@AuthenticationPrincipal UserDetails principal, @RequestBody TransferReq req){
        Account from = accounts.findAll().stream().filter(ac -> ac.getCustomer().getUser().getEmail().equals(principal.getUsername())).findFirst().orElseThrow();
        Account to = accounts.findByAccountNumber(req.toAccountNumber()).orElseThrow();
        accountService.transfer(from, to, req.amount(), "transfer");
        audit.log(principal.getUsername(), "TRANSFER", "to="+req.toAccountNumber()+", amount="+req.amount());
        return ResponseEntity.ok("OK");
    }

    @GetMapping("/transactions")
    public ResponseEntity<List<TxnRes>> transactions(@AuthenticationPrincipal UserDetails principal,
                                                     @RequestParam(required=false) String from,
                                                     @RequestParam(required=false) String to,
                                                     @RequestParam(defaultValue="0") int page,
                                                     @RequestParam(defaultValue="20") int size){
        Account a = accounts.findAll().stream().filter(ac -> ac.getCustomer().getUser().getEmail().equals(principal.getUsername())).findFirst().orElseThrow();
        Instant f = from!=null ? Instant.parse(from) : Instant.EPOCH;
        Instant t = to!=null ? Instant.parse(to) : Instant.now();
        var pageRes = txns.findByAccountAndTimestampBetween(a, f, t, PageRequest.of(page, size));
        var list = pageRes.map(x -> new TxnRes(x.getId(), a.getAccountNumber(), x.getType().name(), x.getAmount(), x.getTimestamp(), x.getReference())).getContent();
        return ResponseEntity.ok(list);
    }
}
