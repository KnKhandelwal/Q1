package com.example.bank.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String actor; // email
    private String action;
    private String details;
    private Instant at = Instant.now();
    public AuditLog() {}
    public AuditLog(String actor, String action, String details) {
        this.actor = actor; this.action = action; this.details = details;
    }
    public Long getId() { return id; }
    public String getActor() { return actor; }
    public String getAction() { return action; }
    public String getDetails() { return details; }
    public Instant getAt() { return at; }
}
