package com.example.bank.domain;
public enum TxnType { DEPOSIT, WITHDRAW, TRANSFER_IN, TRANSFER_OUT }
