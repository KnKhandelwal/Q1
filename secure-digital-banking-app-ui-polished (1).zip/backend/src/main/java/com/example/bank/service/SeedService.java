package com.example.bank.service;

import com.example.bank.domain.*;
import com.example.bank.repo.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class SeedService implements CommandLineRunner {
    private final UserRepository users;
    private final CustomerRepository customers;
    private final AccountRepository accounts;
    private final PasswordEncoder encoder;

    public SeedService(UserRepository users, CustomerRepository customers, AccountRepository accounts, PasswordEncoder encoder) {
        this.users = users; this.customers = customers; this.accounts = accounts; this.encoder = encoder;
    }
    @Override
    public void run(String... args) {
        if (!users.existsByEmail("admin@bank.com")) {
            User admin = new User("admin@bank.com", encoder.encode("Admin@123"), Set.of(Role.ADMIN));
            users.save(admin);
        }
    }
}
