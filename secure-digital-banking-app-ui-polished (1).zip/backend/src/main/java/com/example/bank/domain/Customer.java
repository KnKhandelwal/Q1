package com.example.bank.domain;

import jakarta.persistence.*;

@Entity
public class Customer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;

    @OneToOne(optional = false, cascade = CascadeType.ALL)
    private User user;

    public Customer() {}
    public Customer(String fullName, User user) {
        this.fullName = fullName; this.user = user;
    }
    public Long getId() { return id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
}
