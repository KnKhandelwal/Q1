package com.example.bank.service;

import com.example.bank.domain.AuditLog;
import com.example.bank.repo.AuditLogRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditService {
    private final AuditLogRepository repo;
    public AuditService(AuditLogRepository repo){ this.repo = repo; }
    public void log(String actor, String action, String details){
        repo.save(new AuditLog(actor, action, details));
    }
    public List<AuditLog> all(){ return repo.findAll(); }
}
