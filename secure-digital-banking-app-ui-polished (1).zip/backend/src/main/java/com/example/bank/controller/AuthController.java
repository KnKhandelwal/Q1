package com.example.bank.controller;

import com.example.bank.dto.AuthDtos.*;
import com.example.bank.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;
    public AuthController(AuthService authService){ this.authService = authService; }

    @PostMapping("/register")
    public ResponseEntity<AuthRes> register(@RequestBody @Validated RegisterReq req){
        String token = authService.register(req);
        return ResponseEntity.ok(new AuthRes(token, "CUSTOMER"));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthRes> login(@RequestBody @Validated LoginReq req){
        String token = authService.login(req);
        return ResponseEntity.ok(new AuthRes(token, "N/A"));
    }
}
