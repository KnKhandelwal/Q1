package com.example.bank.repo;
import com.example.bank.domain.Transaction;
import com.example.bank.domain.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.time.Instant;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    Page<Transaction> findByAccountAndTimestampBetween(Account account, Instant from, Instant to, Pageable pageable);
}
