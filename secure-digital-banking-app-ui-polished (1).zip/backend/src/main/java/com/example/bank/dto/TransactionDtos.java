package com.example.bank.dto;

import java.math.BigDecimal;
import java.time.Instant;
public class TransactionDtos {
    public record TxnRes(Long id, String accountNumber, String type, BigDecimal amount, Instant at, String ref) {}
}
