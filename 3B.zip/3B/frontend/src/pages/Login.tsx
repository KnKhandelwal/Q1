import { FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar'
import { api, saveToken } from '../hooks/auth'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      const res = await api().post('/api/auth/login', { username, password })
      saveToken(res.data.token)
      navigate('/')
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Login failed')
    }
  }

  return (
    <div>
      <Navbar />
      <main className="container-lg py-14 flex justify-center">
        <div className="w-full max-w-md">
          <div className="card p-6 space-y-4">
            <h2 className="text-2xl font-bold">Welcome back</h2>
            <p className="text-sm text-gray-500">Sign in to access protected routes and admin area.</p>
            <form onSubmit={onSubmit} className="space-y-3">
              {error && <div className="text-red-600">{error}</div>}
              <input className="input" placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
              <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
              <button className="btn btn-primary w-full" type="submit">Login</button>
            </form>
            <div className="text-sm text-gray-600">No account? <Link to="/register" className="text-indigo-600">Create one</Link></div>
          </div>
        </div>
      </main>
    </div>
  )
}
