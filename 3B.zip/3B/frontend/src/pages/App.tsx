import { useEffect, useMemo, useState } from 'react'
import Navbar from '../components/Navbar'
import ProductCard from '../components/ProductCard'
import CartDrawer from '../components/CartDrawer'
import useCart from '../hooks/auth-cart'
import { Product } from '../types'
import { api } from '../hooks/auth'

export default function App() {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [category, setCategory] = useState('')
  const [products, setProducts] = useState<Product[]>([])
  const { items, add, remove, total, count, clear } = useCart()

  useEffect(() => {
    api().get('/api/products').then(res => setProducts(res.data))
  }, [])

  const categories = useMemo(() => Array.from(new Set(products.map(p => p.category))), [products])

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50">
      <Navbar cartCount={count} />

      <section className="container-lg py-12">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl font-extrabold text-slate-900">Discover great products<br/>for everyday life</h1>
            <p className="text-gray-600 mt-3">Polished UI, fast browsing and a lightweight cart. Login to access protected routes.</p>
            <div className="mt-6 flex gap-3">
              <input className="input" placeholder="Search products..." value={q} onChange={e=>setQ(e.target.value)} />
              <select className="input w-48" value={category} onChange={e=>setCategory(e.target.value)}>
                <option value="">All Categories</option>
                {categories.map(c=> <option key={c} value={c}>{c}</option>)}
              </select>
              <button className="btn btn-primary" onClick={()=>setOpen(true)}>View Cart ({count})</button>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="card p-6">
              <div className="text-sm text-gray-500">Featured</div>
              <div className="mt-3 font-semibold">High performance laptops & accessories</div>
              <div className="mt-6 grid grid-cols-2 gap-3">
                {products.slice(0,4).map(p => (
                  <div key={p.id} className="flex items-center gap-3">
                    <img src={p.thumbnail} className="w-16 h-12 rounded-md object-cover" />
                    <div className="text-sm">
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs text-gray-400">₹{p.price}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="container-lg pb-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.filter(p => (q==='' || p.name.toLowerCase().includes(q.toLowerCase())) && (category==='' || p.category===category))
            .map(p => <ProductCard key={p.id} product={p} onAdd={add} />)}
        </div>
      </main>

      <footer className="footer container-lg">
        <div className="max-w-2xl mx-auto">
          <div className="text-center text-gray-600">Made with ❤️ • 3B Catalog UI — polished and responsive</div>
        </div>
      </footer>

      <CartDrawer open={open} onClose={()=>setOpen(false)} items={items} remove={remove} total={total} clear={clear} />
    </div>
  )
}
