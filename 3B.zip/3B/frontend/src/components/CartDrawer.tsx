import { CartItem } from '../types'

export default function CartDrawer({ open, onClose, items, remove, total, clear }:
 { open: boolean, onClose: () => void, items: CartItem[], remove: (id:number)=>void, total: number, clear: ()=>void }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute right-0 top-0 bottom-0 w-full sm:w-[440px] bg-white p-6 shadow-xl flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">Your Cart</h3>
          <button className="btn btn-ghost" onClick={onClose}>Close</button>
        </div>
        <div className="flex-1 overflow-auto space-y-3">
          {items.length === 0 && <div className="text-gray-500 py-10 text-center">Nothing in cart yet.</div>}
          {items.map(i => (
            <div key={i.product.id} className="flex items-start gap-3 border rounded-xl p-3">
              <img src={i.product.thumbnail} alt={i.product.name} className="w-20 h-20 rounded-md object-cover"/>
              <div className="flex-1">
                <div className="font-medium">{i.product.name}</div>
                <div className="text-sm text-gray-500">Qty: {i.qty} • ₹{i.product.price}</div>
                <div className="text-sm mt-2">Subtotal: ₹{i.qty * i.product.price}</div>
              </div>
              <div className="flex flex-col gap-2">
                <button className="btn btn-outline" onClick={() => remove(i.product.id)}>Remove</button>
              </div>
            </div>
          ))}
        </div>
        <div className="border-t pt-4 mt-4">
          <div className="flex items-center justify-between mb-3">
            <div className="text-lg font-semibold">Total</div>
            <div className="text-lg font-semibold">₹{total}</div>
          </div>
          <div className="flex gap-3">
            <button className="btn btn-ghost flex-1" onClick={clear}>Clear</button>
            <button className="btn btn-primary flex-1" onClick={() => alert('Checkout not implemented')}>Checkout</button>
          </div>
        </div>
      </div>
    </div>
  )
}
