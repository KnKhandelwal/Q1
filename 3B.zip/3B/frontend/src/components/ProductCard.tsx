import { Product } from '../types'
export default function ProductCard({ product, onAdd }: { product: Product, onAdd: (p: Product) => void }) {
  return (
    <div className="card hover:shadow-lg transition p-4">
      <div className="relative">
        <img src={product.thumbnail} alt={product.name} className="product-img" />
        <div className="absolute top-3 left-3 badge">{product.category}</div>
      </div>
      <div className="mt-3 flex items-start justify-between gap-3">
        <div>
          <div className="font-semibold text-slate-800">{product.name}</div>
          <div className="text-sm text-gray-500">{product.brand}</div>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold">₹{product.price}</div>
          <div className="text-xs line-through text-gray-400">₹{product.mrp}</div>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-3">
        <button className="btn btn-primary flex-1" onClick={() => onAdd(product)}>Add to cart</button>
        <button className="btn btn-ghost" onClick={() => window.alert('Open product page for more details')}>Details</button>
      </div>
    </div>
  )
}
