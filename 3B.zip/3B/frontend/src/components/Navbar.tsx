import { Link, useNavigate } from 'react-router-dom'
import { logout, token } from '../hooks/auth'
import { useEffect, useState } from 'react'

export default function Navbar({ cartCount = 0 }: { cartCount?: number }) {
  const navigate = useNavigate()
  const [me, setMe] = useState<any>(null)
  useEffect(() => {
    const t = token()
    if (!t) { setMe(null); return }
    fetch((import.meta.env.VITE_API_BASE||'http://localhost:8080') + '/api/user/me', { headers: { 'Authorization': 'Bearer ' + t } })
      .then(r=>r.ok? r.json(): null).then(d=>setMe(d)).catch(()=>setMe(null))
  }, [token()])

  return (
    <header className="bg-white/90 sticky top-0 z-40 backdrop-blur-md border-b">
      <div className="container-lg py-4 flex items-center gap-4">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-300 flex items-center justify-center text-white font-bold">3B</div>
          <div className="text-lg font-bold text-slate-800">3B Catalog</div>
        </Link>

        <div className="ml-6 hidden md:block">
          <nav className="flex gap-3">
            <Link to="/" className="text-sm text-slate-600 hover:text-slate-900">Products</Link>
            <Link to="/admin" className="text-sm text-slate-600 hover:text-slate-900">Admin</Link>
          </nav>
        </div>

        <div className="ml-auto flex items-center gap-3">
          <Link to="/cart" className="btn btn-ghost !px-3 !py-2 relative">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4" />
            </svg>
            <span className="text-sm">Cart</span>
            <div className="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs px-2 py-0.5 rounded-full">{cartCount}</div>
          </Link>

          {!me ? (
            <div className="flex gap-2 items-center">
              <Link to="/login" className="btn btn-primary">Login</Link>
              <Link to="/register" className="btn btn-ghost">Register</Link>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <div className="text-sm text-slate-700">
                <div className="font-medium">{me.username}</div>
                <div className="text-xs text-gray-400">{Array.from(me.authorities || []).slice(0,2).join(', ')}</div>
              </div>
              <button className="btn btn-ghost" onClick={() => { logout(); navigate('/'); }}>Logout</button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
