import { useEffect, useMemo, useState } from 'react'
import { CartItem, Product } from '../types'

export default function useCart() {
  const [items, setItems] = useState<CartItem[]>(() => {
    try { const raw = localStorage.getItem('3b.cart'); return raw? JSON.parse(raw): [] } catch { return [] }
  })

  useEffect(() => {
    localStorage.setItem('3b.cart', JSON.stringify(items))
  }, [items])

  const add = (product: Product, qty = 1) => {
    setItems(prev => {
      const found = prev.find(i => i.product.id === product.id)
      if (found) return prev.map(i => i.product.id === product.id? {...i, qty: i.qty + qty}: i)
      return [...prev, { product, qty }]
    })
  }
  const remove = (id:number) => setItems(prev => prev.filter(i => i.product.id !== id))
  const clear = () => setItems([])
  const total = useMemo(() => items.reduce((s,i)=>s + i.product.price * i.qty, 0), [items])
  const count = useMemo(() => items.reduce((s,i)=>s + i.qty, 0), [items])
  return { items, add, remove, clear, total, count }
}
