# 3B — Polished UI for JWT Catalog

Improved frontend UI over 3A.