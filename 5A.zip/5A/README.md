# 5A — Real-time Chat (Spring Boot WebSocket + React)

Features:
- WebSocket (STOMP + SockJS) endpoint at /ws
- Topic: /topic/public - clients subscribe to receive messages
- App destination: /app/chat.send - send messages to server which broadcasts them
- Frontend uses @stomp/stompjs + sockjs-client to connect, send and receive
- Simple UI, auto-scroll, reconnects

Run backend:
cd backend
mvn spring-boot:run

Run frontend:
cd frontend
npm install
npm run dev
