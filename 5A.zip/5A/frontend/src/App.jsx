import React, { useState, useEffect } from 'react';
import SockJS from 'sockjs-client';
import Stomp from 'stompjs';

let stompClient = null;

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [username, setUsername] = useState('User' + Math.floor(Math.random() * 1000));

  useEffect(() => {
    const socket = new SockJS('http://localhost:8080/ws');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, () => {
      stompClient.subscribe('/topic/messages', (message) => {
        setMessages(prev => [...prev, JSON.parse(message.body)]);
      });
    });
  }, []);

  const sendMessage = () => {
    if (input.trim() !== '') {
      stompClient.send('/app/sendMessage', {}, JSON.stringify({ from: username, content: input }));
      setInput('');
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: '0 auto', padding: 20 }}>
      <h2>Real-time Chat</h2>
      <div style={{ border: '1px solid #ccc', height: 300, overflowY: 'auto', padding: 10, marginBottom: 10 }}>
        {messages.map((msg, index) => (
          <div key={index}><strong>{msg.from}:</strong> {msg.content}</div>
        ))}
      </div>
      <input
        type="text"
        placeholder="Type a message..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        style={{ width: '80%', padding: 5 }}
      />
      <button onClick={sendMessage} style={{ width: '18%', marginLeft: '2%' }}>Send</button>
    </div>
  );
}
