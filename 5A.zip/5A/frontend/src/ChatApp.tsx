import React, { useEffect, useRef, useState } from 'react';
import { Client, IMessage } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import './styles.css';

const WS_URL = (import.meta.env.VITE_WS_URL || 'http://localhost:8080') + '/ws';

type Msg = { sender: string; content: string; timestamp: number };

export default function ChatApp(){
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [name, setName] = useState('User' + Math.floor(Math.random()*900+100));
  const clientRef = useRef<Client | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);

  useEffect(()=>{
    const client = new Client({
      webSocketFactory: () => new SockJS(WS_URL) as any,
      onConnect: () => {
        setConnected(true);
        client.subscribe('/topic/public', (msg:IMessage) => {
          try{
            const body = JSON.parse(msg.body);
            setMessages(prev => [...prev, body]);
          }catch(e){}
        });
      },
      onDisconnect: () => setConnected(false),
      reconnectDelay: 5000
    });
    client.activate();
    clientRef.current = client;
    return ()=>{ client.deactivate(); clientRef.current = null; }
  }, []);

  useEffect(()=>{ if(listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight; }, [messages]);

  const send = ()=>{
    if(!text.trim()) return;
    const m = { sender: name, content: text.trim(), timestamp: Date.now() };
    clientRef.current?.publish({ destination: '/app/chat.send', body: JSON.stringify(m) });
    setText('');
  }

  return (<div className="container">
    <div className="card">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h2>5A — Live Chat</h2>
        <div>{connected? <span style={{color:'#059669'}}>Connected</span> : <span style={{color:'#ef4444'}}>Disconnected</span>}</div>
      </div>
      <div className="meta" style={{marginTop:8}}>You are <strong>{name}</strong>. Change name: <input value={name} onChange={e=>setName(e.target.value)} style={{marginLeft:8,padding:6,borderRadius:8}}/></div>

      <div ref={listRef} style={{maxHeight:320,overflow:'auto',marginTop:12,padding:8,borderRadius:8,background:'#f8fafc'}}>
        {messages.map((m,i)=>(
          <div key={i} className={'message ' + (m.sender===name? 'own':'other')}>
            <div style={{fontWeight:600}}>{m.sender}</div>
            <div style={{marginTop:6}}>{m.content}</div>
            <div className="meta" style={{marginTop:6}}>{new Date(m.timestamp).toLocaleString()}</div>
          </div>
        ))}
      </div>

      <div className="input-row">
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message..." style={{flex:1,padding:10,borderRadius:8,border:'1px solid #e6e6f0'}} onKeyDown={e=>{ if(e.key==='Enter') send(); }} />
        <button onClick={send} style={{padding:'10px 14px',borderRadius:8,background:'#6366f1',color:'#fff',border:'none'}}>Send</button>
      </div>
    </div>
  </div>)
}
