package com.example.task1a.user;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserService {
    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public List<User> findAll() {
        return repository.findAll();
    }

    public User findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public User create(User user) {
        repository.findByEmail(user.getEmail()).ifPresent(u -> { throw new RuntimeException("Email already exists"); });
        return repository.save(user);
    }

    public User update(Long id, User data) {
        User u = findById(id);
        u.setName(data.getName());
        u.setEmail(data.getEmail());
        u.setPhone(data.getPhone());
        u.setBio(data.getBio());
        u.setAvatarUrl(data.getAvatarUrl());
        return repository.save(u);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}