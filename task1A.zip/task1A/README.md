# task1A

Backend: Spring Boot 3, H2, JPA.  
Frontend: React + Vite, Axios, Zustand, React Router.

## Run
### Backend
cd backend
./mvnw spring-boot:run (or mvn spring-boot:run)

### Frontend
cd frontend
npm i
npm run dev