import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useUserStore } from '../../api/store'
import api from '../../api/client'

const initial = { name: '', email: '', phone: '', bio: '', avatarUrl: '' }

export default function UserForm({ mode }) {
  const { createUser, updateUser } = useUserStore()
  const [data, setData] = useState(initial)
  const { id } = useParams()
  const nav = useNavigate()

  useEffect(() => {
    if (mode === 'edit' && id) {
      api.get(`/users/${id}`).then(r => setData(r.data))
    }
  }, [mode, id])

  const submit = async (e) => {
    e.preventDefault()
    if (mode === 'create') {
      const u = await createUser(data)
      nav(`/users/${u.id}`)
    } else {
      const u = await updateUser(Number(id), data)
      nav(`/users/${u.id}`)
    }
  }

  return (
    <form className="form grid" onSubmit={submit}>
      <input className="input" placeholder="Name" value={data.name} onChange={e => setData({ ...data, name: e.target.value })} required minLength={2} maxLength={100} />
      <input className="input" placeholder="Email" type="email" value={data.email} onChange={e => setData({ ...data, email: e.target.value })} required />
      <input className="input" placeholder="Phone" value={data.phone} onChange={e => setData({ ...data, phone: e.target.value })} />
      <input className="input" placeholder="Avatar URL" value={data.avatarUrl} onChange={e => setData({ ...data, avatarUrl: e.target.value })} />
      <textarea className="input" placeholder="Bio" rows="4" value={data.bio} onChange={e => setData({ ...data, bio: e.target.value })} />
      <div className="toolbar">
        <button type="button" className="ghost" onClick={() => nav(-1)}>Cancel</button>
        <button type="submit">{mode === 'create' ? 'Create' : 'Update'}</button>
      </div>
    </form>
  )
}