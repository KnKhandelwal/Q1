import { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useUserStore } from '../../api/store'

export default function UserList() {
  const { users, fetchUsers, deleteUser, loading } = useUserStore()
  const nav = useNavigate()
  useEffect(() => { fetchUsers() }, [])
  return (
    <div className="grid">
      <div className="list">
        {users.map(u => (
          <div className="card" key={u.id}>
            <img className="avatar" src={u.avatarUrl || 'https://i.pravatar.cc/100'} alt="" />
            <div className="meta">
              <div className="name">{u.name}</div>
              <div className="muted">{u.email}</div>
            </div>
            <div className="actions">
              <Link className="ghost" to={`/users/${u.id}`}><button className="ghost">View</button></Link>
              <button className="ghost" onClick={() => nav(`/edit/${u.id}`)}>Edit</button>
              <button onClick={() => deleteUser(u.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}