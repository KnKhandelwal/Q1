import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '../../api/client'

export default function UserView() {
  const { id } = useParams()
  const [user, setUser] = useState(null)
  const nav = useNavigate()
  useEffect(() => {
    api.get(`/users/${id}`).then(r => setUser(r.data))
  }, [id])
  if (!user) return null
  return (
    <div className="view">
      <div className="card" style={{marginBottom:16}}>
        <img className="avatar" src={user.avatarUrl || 'https://i.pravatar.cc/100'} alt="" />
        <div className="meta">
          <div className="name">{user.name}</div>
          <div className="muted">{user.email}</div>
          <div className="muted">{user.phone}</div>
        </div>
      </div>
      <div className="muted" style={{marginBottom:12}}>{user.bio}</div>
      <div className="toolbar">
        <button className="ghost" onClick={() => nav(-1)}>Back</button>
        <button onClick={() => nav(`/edit/${user.id}`)}>Edit</button>
      </div>
    </div>
  )
}