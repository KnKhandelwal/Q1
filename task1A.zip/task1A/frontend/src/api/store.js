import { create } from 'zustand'
import api from './client'

export const useUserStore = create((set, get) => ({
  users: [],
  loading: false,
  fetchUsers: async () => {
    set({ loading: true })
    const res = await api.get('/users')
    set({ users: res.data, loading: false })
  },
  createUser: async (payload) => {
    const res = await api.post('/users', payload)
    set({ users: [res.data, ...get().users] })
    return res.data
  },
  updateUser: async (id, payload) => {
    const res = await api.put(`/users/${id}`, payload)
    set({ users: get().users.map(u => u.id === id ? res.data : u) })
    return res.data
  },
  deleteUser: async (id) => {
    await api.delete(`/users/${id}`)
    set({ users: get().users.filter(u => u.id !== id) })
  }
}))