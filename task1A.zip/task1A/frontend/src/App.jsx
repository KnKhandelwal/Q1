import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import UserList from './features/users/UserList.jsx'
import UserView from './features/users/UserView.jsx'
import UserForm from './features/users/UserForm.jsx'

export default function App() {
  return (
    <div className="container">
      <header className="header">
        <h1>task1A</h1>
        <nav className="nav">
          <Link to="/">Users</Link>
          <Link to="/create">Create</Link>
        </nav>
      </header>
      <Routes>
        <Route path="/" element={<UserList />} />
        <Route path="/users/:id" element={<UserView />} />
        <Route path="/create" element={<UserForm mode="create" />} />
        <Route path="/edit/:id" element={<UserForm mode="edit" />} />
      </Routes>
    </div>
  )
}